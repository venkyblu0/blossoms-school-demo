/* Opens the admission poster as a pop-up on the home page, once per browser session. */
( function () {
	var popup = document.querySelector( '.wp-site-blocks .bh-admission-popup' );
	if ( ! popup ) {
		return;
	}
	try {
		if ( sessionStorage.getItem( 'bhAdmissionPopupSeen' ) ) {
			return;
		}
		sessionStorage.setItem( 'bhAdmissionPopupSeen', '1' );
	} catch ( e ) {}

	var previousFocus = document.activeElement;
	var overlay = document.createElement( 'div' );
	overlay.className = 'bh-popup-overlay';
	overlay.setAttribute( 'role', 'dialog' );
	overlay.setAttribute( 'aria-modal', 'true' );
	overlay.setAttribute( 'aria-label', 'Admissions open' );

	var close = document.createElement( 'button' );
	close.type = 'button';
	close.className = 'bh-popup-close';
	close.setAttribute( 'aria-label', 'Close' );
	close.innerHTML = '&times;';

	popup.parentNode.removeChild( popup );
	popup.appendChild( close );
	overlay.appendChild( popup );
	document.body.appendChild( overlay );
	close.focus();

	function hide() {
		overlay.remove();
		document.removeEventListener( 'keydown', onKey );
		if ( previousFocus && previousFocus.focus ) {
			previousFocus.focus();
		}
	}
	function onKey( e ) {
		if ( e.key === 'Escape' ) {
			hide();
		}
	}
	close.addEventListener( 'click', hide );
	overlay.addEventListener( 'click', function ( e ) {
		if ( e.target === overlay ) {
			hide();
		}
	} );
	document.addEventListener( 'keydown', onKey );
} )();
