<?php
/**
 * Blossoms Heritage — theme setup.
 */

define( 'BLOSSOMS_HERITAGE_FONTS', 'https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600;700&family=Tiro+Devanagari+Hindi&family=Young+Serif&display=swap' );

add_action( 'after_setup_theme', function () {
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_editor_style( array( BLOSSOMS_HERITAGE_FONTS, 'style.css' ) );
} );

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'blossoms-heritage-fonts', BLOSSOMS_HERITAGE_FONTS, array(), null );
	wp_enqueue_style( 'blossoms-heritage', get_stylesheet_uri(), array(), wp_get_theme()->get( 'Version' ) );
	if ( is_front_page() ) {
		wp_enqueue_script( 'blossoms-heritage-admission-popup', get_theme_file_uri( 'assets/admission-popup.js' ), array(), wp_get_theme()->get( 'Version' ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
	}
} );

add_action( 'init', function () {
	register_block_pattern_category( 'blossoms', array( 'label' => __( 'Blossoms School', 'blossoms-heritage' ) ) );

	register_block_style( 'core/table', array( 'name' => 'honours-board', 'label' => __( 'Honours board', 'blossoms-heritage' ) ) );
	register_block_style( 'core/image', array( 'name' => 'arch', 'label' => __( 'Arch window', 'blossoms-heritage' ) ) );
	register_block_style( 'core/group', array( 'name' => 'brass-frame', 'label' => __( 'Brass frame', 'blossoms-heritage' ) ) );
} );
