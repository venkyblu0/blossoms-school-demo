<?php
/**
 * Title: Admission pop-up
 * Slug: blossoms-heritage/admission-popup
 * Categories: blossoms, call-to-action
 * Description: The admission poster that pops up when the home page opens (once per visit). Swap the image to change the poster; remove this block to turn the pop-up off.
 */
$poster = function_exists( 'blossoms_admission_poster_url' )
	? blossoms_admission_poster_url()
	: 'https://blossomshighschool.org/wp-content/uploads/2026/10/Admission-2027-28-1_page-0001.jpg';
?>
<!-- wp:group {"className":"bh-admission-popup","layout":{"type":"constrained"}} -->
<div class="wp-block-group bh-admission-popup"><!-- wp:image {"sizeSlug":"large","linkDestination":"custom","className":"bh-popup-poster"} -->
<figure class="wp-block-image size-large bh-popup-poster"><a href="<?php echo esc_url( home_url( '/admissions/' ) ); ?>"><img src="<?php echo esc_url( $poster ); ?>" alt="Admissions Open for the Academic Year 2027–2028. Nursery, L.K.G., H.K.G. and Grade 1."/></a></figure>
<!-- /wp:image -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( home_url( '/admissions/' ) ); ?>">View admission details</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->
