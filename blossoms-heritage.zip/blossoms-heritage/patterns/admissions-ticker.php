<?php
/**
 * Title: Admissions scrolling text
 * Slug: blossoms-heritage/admissions-ticker
 * Categories: blossoms, banner
 * Description: A strip of scrolling text above the header announcing admissions. Edit the text or link like any paragraph.
 */
?>
<!-- wp:group {"className":"bh-ticker","style":{"spacing":{"padding":{"top":"0.55rem","bottom":"0.55rem"}}},"backgroundColor":"vermilion","textColor":"paper","layout":{"type":"default"}} -->
<div class="wp-block-group bh-ticker has-paper-color has-vermilion-background-color has-text-color has-background" style="padding-top:0.55rem;padding-bottom:0.55rem"><!-- wp:paragraph -->
<p><a href="<?php echo esc_url( home_url( '/admissions/' ) ); ?>"><strong>Admissions Open for the Academic Year 2027 – 2028</strong> · Nursery, L.K.G., H.K.G. &amp; Grade 1 · Click here for details</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
