<?php
/**
 * Title: Heritage footer
 * Slug: blossoms-heritage/footer-content
 * Categories: blossoms, footer
 * Inserter: no
 * Description: Footer with motto, contact details and quick links, plus the right-side "Admissions Open" tab.
 */
?>
<!-- wp:group {"className":"bh-footer","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|40"}},"elements":{"link":{"color":{"text":"#F3EBD9"}}}},"backgroundColor":"ink-deep","textColor":"mist","layout":{"type":"constrained"}} -->
<div class="wp-block-group bh-footer has-mist-color has-ink-deep-background-color has-text-color has-background has-link-color" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--40)"><!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"left":"3rem"}}}} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"width":"38%"} -->
<div class="wp-block-column" style="flex-basis:38%"><!-- wp:paragraph {"className":"bh-motto","style":{"typography":{"fontSize":"2rem"}},"textColor":"brass"} -->
<p class="bh-motto has-brass-color has-text-color" style="font-size:2rem">तमसो मा ज्योतिर्गमय</p>
<!-- /wp:paragraph -->

<!-- wp:site-title {"level":0,"style":{"typography":{"fontSize":"1.15rem"}},"fontFamily":"display"} /-->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"0.9rem"}}} -->
<p style="font-size:0.9rem">ICSE school affiliated to CISCE (Affiliation No. MA 297). Nursery to Grade 10, New Marine Lines, Mumbai.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"0.75rem","letterSpacing":"0.16em","textTransform":"uppercase"}},"textColor":"brass","fontFamily":"body"} -->
<h3 class="wp-block-heading has-brass-color has-text-color has-body-font-family" style="font-size:0.75rem;letter-spacing:0.16em;text-transform:uppercase">Contact</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"0.95rem"}}} -->
<p style="font-size:0.95rem">2 – 2A Nathibai Thackersey Road<br>New Marine Lines, Mumbai</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"0.95rem"}}} -->
<p style="font-size:0.95rem"><a href="tel:+912222015672">022 2201 5672</a> · <a href="tel:+912222088778">022 2208 8778</a><br><a href="tel:+919152133242">91521 33242</a><br><a href="mailto:blossomshighschool77@gmail.com">blossomshighschool77@gmail.com</a><br>Admissions: <a href="mailto:blossomsadmission@gmail.com">blossomsadmission@gmail.com</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"0.75rem","letterSpacing":"0.16em","textTransform":"uppercase"}},"textColor":"brass","fontFamily":"body"} -->
<h3 class="wp-block-heading has-brass-color has-text-color has-body-font-family" style="font-size:0.75rem;letter-spacing:0.16em;text-transform:uppercase">Quick links</h3>
<!-- /wp:heading -->

<!-- wp:list {"className":"bh-plain-list"} -->
<ul class="wp-block-list bh-plain-list"><!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/admissions/' ) ); ?>">Admissions Open 2027–28</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/about-us/' ) ); ?>">About the school</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/our-toppers/' ) ); ?>">Our toppers</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/news/' ) ); ?>">News &amp; events</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/career/' ) ); ?>">Career</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Contact</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:separator {"align":"wide","className":"is-style-wide"} -->
<hr class="wp-block-separator alignwide has-alpha-channel-opacity is-style-wide"/>
<!-- /wp:separator -->

<!-- wp:paragraph {"align":"wide","style":{"typography":{"fontSize":"0.8rem"}}} -->
<p class="alignwide" style="font-size:0.8rem">© The Blossoms Sunderbai Thackersey English High School. All rights reserved.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:buttons {"className":"bh-side-tab"} -->
<div class="wp-block-buttons bh-side-tab"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( home_url( '/admissions/' ) ); ?>">Admissions Open</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
