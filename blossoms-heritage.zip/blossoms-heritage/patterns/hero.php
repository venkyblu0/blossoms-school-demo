<?php
/**
 * Title: Heritage hero — motto
 * Slug: blossoms-heritage/hero
 * Categories: blossoms, banner
 * Description: School motto, name and an arched photograph of the school.
 */
$img = 'https://blossomshighschool.org/wp-content/uploads/2025/08/school-gate-scaled.jpg';
?>
<!-- wp:group {"align":"full","className":"bh-hero","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"backgroundColor":"ink","textColor":"paper","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull bh-hero has-paper-color has-ink-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:columns {"verticalAlignment":"center","align":"wide","style":{"spacing":{"blockGap":{"left":"clamp(2rem, 6vw, 6rem)"}}}} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"58%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:58%"><!-- wp:paragraph {"className":"bh-eyebrow","style":{"typography":{"fontSize":"0.78rem","fontWeight":"600"}},"textColor":"brass"} -->
<p class="bh-eyebrow has-brass-color has-text-color" style="font-size:0.78rem;font-weight:600">Our motto</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"className":"bh-motto","textColor":"vermilion","fontSize":"motto"} -->
<h1 class="wp-block-heading bh-motto has-vermilion-color has-text-color has-motto-font-size">तमसो मा ज्योतिर्गमय</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontStyle":"italic"}},"fontSize":"x-large","fontFamily":"display"} -->
<p class="has-display-font-family has-x-large-font-size" style="font-style:italic">Lead us from darkness to light.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"typography":{"lineHeight":"1.7"}},"textColor":"mist","fontSize":"medium"} -->
<p class="has-mist-color has-text-color has-medium-font-size" style="line-height:1.7">The Blossoms Sunderbai Thackersey English High School is an ICSE school on Nathibai Thackersey Road, Mumbai, teaching children from Nursery to Grade 10 with care, discipline and curiosity.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--40)"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( home_url( '/about-us/' ) ); ?>">About the school</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-outline","style":{"color":{"text":"#FBFAF7"}}} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link has-text-color wp-element-button" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" style="color:#FBFAF7">Visit us</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"42%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:42%"><!-- wp:image {"sizeSlug":"large","className":"is-style-arch"} -->
<figure class="wp-block-image size-large is-style-arch"><img src="<?php echo esc_url( $img ); ?>" alt="The Blossoms school gate on Nathibai Thackersey Road"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
