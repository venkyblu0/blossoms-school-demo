<?php
/**
 * Title: Heritage Board of Honour
 * Slug: blossoms-heritage/honours-board
 * Categories: blossoms, text
 * Description: Year-by-year Grade 10 board toppers, styled like a school honours board. Edit the rows like any table.
 */
$toppers = array(
	array( '2025', 'Yatharth R. Patel', '483 / 500' ),
	array( '2024', 'Yashvi Sejal', '97.60%' ),
	array( '2023', 'Jai Daksh R.', '97.20%' ),
	array( '2022', 'Shah Pratham R.', '97.40%' ),
	array( '2021', 'Raut Chaitaniya M.', '93.20%' ),
	array( '2020', 'Doshi Viral B.', '96.40%' ),
	array( '2019', 'Kothari Raj K.', '93.60%' ),
	array( '2018', 'Raigagla Dhrumil G.', '97.60%' ),
	array( '2017', 'Chaudhari Dhawal J.', '98.20%' ),
	array( '2016', 'Punamiya Riya', '95.20%' ),
	array( '2015', 'Vora Priyam', '95.40%' ),
	array( '2014', 'Chatrissa Shabbir M.', '94.60%' ),
	array( '2013', 'Shah Neel P.', '95.09%' ),
	array( '2012', 'Jain Monish R.', '100.00%' ),
	array( '2011', 'Shah Isha M.', '95.64%' ),
	array( '2010', 'Kotadia Kinjal H. &amp; Shah Vatsal J.', '94.55%' ),
	array( '2009', 'Jain Janam A.', '92.92%' ),
	array( '2008', 'Chadwa Dhwani C.', '92.45%' ),
	array( '2007', 'Chheda Adarsh J.', '90.00%' ),
	array( '2006', 'Sanghvi Yash P. &amp; Shah Manit K.', '89.73%' ),
	array( '2005', 'Jhaveri Mohak R.', '91.20%' ),
	array( '2004', 'Desai Grishma G. &amp; Udeshi Varun M.', '90.26%' ),
	array( '2003', 'Parekh Karishma P.', '90.26%' ),
	array( '2002', 'Salvi Satej S.', '90.00%' ),
	array( '2001', 'Lodha Shweta M.', '84.40%' ),
	array( '2000', 'Duldhoya Dhara K.', '88.66%' ),
	array( '1999', 'Shah Jai M.', '85.20%' ),
	array( '1998', 'Bandukwala Farida H.', '89.20%' ),
);
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"backgroundColor":"ink-deep","textColor":"paper","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-paper-color has-ink-deep-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:group {"align":"wide","className":"is-style-brass-frame","style":{"spacing":{"padding":{"top":"clamp(2rem, 5vw, 4rem)","bottom":"clamp(2rem, 5vw, 4rem)","left":"clamp(1.5rem, 5vw, 4rem)","right":"clamp(1.5rem, 5vw, 4rem)"}},"border":{"radius":"6px"}},"backgroundColor":"ink","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide is-style-brass-frame has-ink-background-color has-background" style="border-radius:6px;padding-top:clamp(2rem, 5vw, 4rem);padding-right:clamp(1.5rem, 5vw, 4rem);padding-bottom:clamp(2rem, 5vw, 4rem);padding-left:clamp(1.5rem, 5vw, 4rem)"><!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"clamp(2rem, 5vw, 4rem)"}}}} -->
<div class="wp-block-columns"><!-- wp:column {"width":"36%"} -->
<div class="wp-block-column" style="flex-basis:36%"><!-- wp:paragraph {"style":{"typography":{"fontSize":"0.78rem","fontWeight":"600","letterSpacing":"0.16em","textTransform":"uppercase"}},"textColor":"brass"} -->
<p class="has-brass-color has-text-color" style="font-size:0.78rem;font-weight:600;letter-spacing:0.16em;text-transform:uppercase">Board of Honour</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-xx-large-font-size">Twenty-eight years of toppers.</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"mist"} -->
<p class="has-mist-color has-text-color">Every name on this board topped the school in the Grade 10 board examination. In each of those years, the whole batch passed.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><a href="<?php echo esc_url( home_url( '/achievements/' ) ); ?>" style="color:#C99A3A">See all achievements</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"64%"} -->
<div class="wp-block-column" style="flex-basis:64%"><!-- wp:group {"className":"bh-board-scroll","layout":{"type":"default"}} -->
<div class="wp-block-group bh-board-scroll"><!-- wp:table {"hasFixedLayout":false,"className":"is-style-honours-board"} -->
<figure class="wp-block-table is-style-honours-board"><table><thead><tr><th>Year</th><th>School topper</th><th>Score</th></tr></thead><tbody><?php foreach ( $toppers as $row ) : ?><tr><td><?php echo $row[0]; ?></td><td><?php echo $row[1]; ?></td><td><?php echo $row[2]; ?></td></tr><?php endforeach; ?></tbody></table></figure>
<!-- /wp:table --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
