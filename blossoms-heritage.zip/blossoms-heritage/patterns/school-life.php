<?php
/**
 * Title: Heritage school life gallery and visit
 * Slug: blossoms-heritage/school-life
 * Categories: blossoms, gallery
 * Description: Photo gallery of school life, links to clubs and events, and a visit call-to-action.
 */
$u = 'https://blossomshighschool.org/wp-content/uploads/';
$photos = array(
	array( '2024/08/IMGL1607.jpg', 'March past at Annual Sports Day' ),
	array( '2024/10/453503617_892053436277208_2089213014608411262_n.jpg', 'Eco Club students at work' ),
	array( '2024/08/T-B-S-A-D-1101_resize.jpg', 'A performance at Annual Day' ),
	array( '2026/04/photo_2026-04-17_14-23-51-3.jpg', 'Students receiving an award' ),
);
?>
<!-- wp:group {"align":"full","className":"bh-life","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull bh-life" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"left":"3rem"}}}} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"width":"34%"} -->
<div class="wp-block-column" style="flex-basis:34%"><!-- wp:heading {"fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-xx-large-font-size">Life beyond the classroom</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"slate"} -->
<p class="has-slate-color has-text-color">Clubs, sport, festivals and trips fill the school year. Every child finds something to belong to.</p>
<!-- /wp:paragraph -->

<!-- wp:list {"className":"bh-plain-list"} -->
<ul class="wp-block-list bh-plain-list"><!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/clubs/' ) ); ?>">Eco, Literary &amp; Science Clubs</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/coaching/' ) ); ?>">Sports coaching</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/events/' ) ); ?>">Annual Day &amp; Sports Day</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/activities/' ) ); ?>">Picnics &amp; summer camp</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"66%"} -->
<div class="wp-block-column" style="flex-basis:66%"><!-- wp:gallery {"columns":2,"linkTo":"none","sizeSlug":"large","style":{"spacing":{"blockGap":{"top":"0.75rem","left":"0.75rem"}}}} -->
<figure class="wp-block-gallery has-nested-images columns-2 is-cropped"><?php foreach ( $photos as $p ) : ?><!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo esc_url( $u . $p[0] ); ?>" alt="<?php echo esc_attr( $p[1] ); ?>"/></figure>
<!-- /wp:image --><?php endforeach; ?></figure>
<!-- /wp:gallery --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"backgroundColor":"vermilion","textColor":"paper","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-paper-color has-vermilion-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:group {"align":"wide","layout":{"type":"flex","justifyContent":"space-between","flexWrap":"wrap"}} -->
<div class="wp-block-group alignwide"><!-- wp:heading {"fontSize":"x-large"} -->
<h2 class="wp-block-heading has-x-large-font-size">Come and see the school for yourself.</h2>
<!-- /wp:heading -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"ink","textColor":"paper"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-paper-color has-ink-background-color has-text-color has-background wp-element-button" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Book a visit</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
