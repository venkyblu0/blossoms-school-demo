<?php
/**
 * Title: Heritage welcome — facts, history and mission
 * Slug: blossoms-heritage/welcome
 * Categories: blossoms, about
 * Description: Four facts about the school followed by its history and mission.
 */
$img = 'https://blossomshighschool.org/wp-content/uploads/2024/08/T-B-S-A-D-0927_resize.jpg';
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:columns {"align":"wide","className":"bh-facts","style":{"spacing":{"blockGap":{"left":"2rem"}}}} -->
<div class="wp-block-columns alignwide bh-facts"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">ICSE curriculum</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"slate","fontSize":"small"} -->
<p class="has-slate-color has-text-color has-small-font-size">Affiliated to the Council for the Indian School Certificate Examinations, No. MA 297.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Nursery to Grade 10</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"slate","fontSize":"small"} -->
<p class="has-slate-color has-text-color has-small-font-size">Nursery, Pre-Primary, Primary and Secondary sections under one roof.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">100% board results</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"slate","fontSize":"small"} -->
<p class="has-slate-color has-text-color has-small-font-size">Every student has passed the Grade 10 board examination, every year since 1998.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">School hours</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"slate","fontSize":"small"} -->
<p class="has-slate-color has-text-color has-small-font-size">Primary &amp; Secondary 8:45 am – 3:15 pm. Pre-Primary 8:45 am – 12 noon.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"verticalAlignment":"center","align":"wide","style":{"spacing":{"margin":{"top":"var:preset|spacing|60"},"blockGap":{"left":"clamp(2rem, 6vw, 5rem)"}}}} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center" style="margin-top:var(--wp--preset--spacing--60)"><!-- wp:column {"verticalAlignment":"center","width":"45%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:45%"><!-- wp:image {"sizeSlug":"large","style":{"border":{"radius":"14px"}}} -->
<figure class="wp-block-image size-large has-custom-border"><img src="<?php echo esc_url( $img ); ?>" alt="Students performing on stage at Annual Day" style="border-radius:14px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"55%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:55%"><!-- wp:paragraph {"style":{"typography":{"fontSize":"0.78rem","fontWeight":"600","letterSpacing":"0.14em","textTransform":"uppercase"}},"textColor":"vermilion"} -->
<p class="has-vermilion-color has-text-color" style="font-size:0.78rem;font-weight:600;letter-spacing:0.14em;text-transform:uppercase">About the school</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-xx-large-font-size">From 30 “Little Angels” to 1,000 students.</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"slate"} -->
<p class="has-slate-color has-text-color">The school was renamed The Blossoms Sunderbai Thackersey English School in 1981, and in 1993 it was rechristened The Blossoms Sunderbai Thackersey English High School. From 30 “Little Angels”, it has bloomed to the SSC level with a strength of 1,000 students.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"textColor":"slate"} -->
<p class="has-slate-color has-text-color">Our mission is to provide high-quality, meaningful education in a learning environment that empowers children to become confident, compassionate and responsible learners.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><a href="<?php echo esc_url( home_url( '/about-us/' ) ); ?>">Read more about us</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
