<?php
/**
 * Plugin Name: Blossoms Site Content
 * Description: Imports the content of blossomshighschool.org (pages, 680 news posts, categories, menu, logo) into a fresh WordPress for the Blossoms Heritage demo, and adds the Admissions Open 2027–28 page. Photos stay on blossomshighschool.org and are linked, not copied.
 * Version: 1.0.0
 * Author: Scholr Services
 * License: GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

/** Site-relative link that also works when WordPress lives in a sub-folder (e.g. WordPress Playground). */
function blossoms_url( $slug = '' ) {
	return home_url( $slug ? '/' . trim( $slug, '/' ) . '/' : '/' );
}

/** The admission poster in the Media Library (imported from assets/admission-poster.jpg). */
function blossoms_admission_poster_url() {
	$id = (int) get_option( 'blossoms_admission_poster_id' );
	return $id ? wp_get_attachment_url( $id ) : plugins_url( 'assets/admission-poster.jpg', __FILE__ );
}

/** Copies a bundled file into the uploads folder and registers it in the Media Library. */
function blossoms_import_asset( $file, $title, $mime ) {
	$upload = wp_upload_bits( $file, null, file_get_contents( __DIR__ . '/assets/' . $file ) );
	if ( ! empty( $upload['error'] ) ) {
		return 0;
	}
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$id = wp_insert_attachment( array( 'post_mime_type' => $mime, 'post_title' => $title, 'post_status' => 'inherit' ), $upload['file'] );
	wp_update_attachment_metadata( $id, wp_generate_attachment_metadata( $id, $upload['file'] ) );
	return $id;
}

register_activation_hook( __FILE__, 'blossoms_site_import' );

/* Featured images stay on the school's current site: render them from the stored URL. */
add_filter( 'render_block_core/post-featured-image', function ( $html, $block, $instance ) {
	$post_id = isset( $instance->context['postId'] ) ? $instance->context['postId'] : get_the_ID();
	if ( '' !== trim( $html ) || ! $post_id || has_post_thumbnail( $post_id ) ) {
		return $html;
	}
	$src = get_post_meta( $post_id, '_blossoms_remote_thumb', true );
	if ( ! $src ) {
		return $html;
	}
	$attrs = $block['attrs'];
	$style = 'width:100%;object-fit:cover;' . ( ! empty( $attrs['aspectRatio'] ) ? 'aspect-ratio:' . $attrs['aspectRatio'] . ';' : '' );
	$img   = sprintf( '<img src="%s" alt="%s" style="%s" loading="lazy" />', esc_url( $src ), esc_attr( get_the_title( $post_id ) ), esc_attr( $style ) );
	if ( ! empty( $attrs['isLink'] ) ) {
		$img = '<a href="' . esc_url( get_permalink( $post_id ) ) . '">' . $img . '</a>';
	}
	$class = 'wp-block-post-featured-image' . ( ! empty( $attrs['align'] ) ? ' align' . $attrs['align'] : '' );
	return '<figure class="' . esc_attr( $class ) . '">' . $img . '</figure>';
}, 10, 3 );

function blossoms_b_p( $html ) {
	return "<!-- wp:paragraph -->\n<p>$html</p>\n<!-- /wp:paragraph -->\n\n";
}
function blossoms_b_h( $text, $level = 2 ) {
	$attrs = 2 === $level ? '' : ' {"level":' . $level . '}';
	return "<!-- wp:heading$attrs -->\n<h$level class=\"wp-block-heading\">$text</h$level>\n<!-- /wp:heading -->\n\n";
}
function blossoms_b_list( $items ) {
	$out = "<!-- wp:list -->\n<ul class=\"wp-block-list\">";
	foreach ( $items as $item ) {
		$out .= "<!-- wp:list-item -->\n<li>$item</li>\n<!-- /wp:list-item -->";
	}
	return $out . "</ul>\n<!-- /wp:list -->\n\n";
}
function blossoms_b_table( $rows, $head = null ) {
	$t = '';
	if ( $head ) {
		$t .= '<thead><tr>' . implode( '', array_map( fn( $c ) => "<th>$c</th>", $head ) ) . '</tr></thead>';
	}
	$t .= '<tbody>';
	foreach ( $rows as $r ) {
		$t .= '<tr>' . implode( '', array_map( fn( $c ) => "<td>$c</td>", $r ) ) . '</tr>';
	}
	return "<!-- wp:table -->\n<figure class=\"wp-block-table\"><table>$t</tbody></table></figure>\n<!-- /wp:table -->\n\n";
}
function blossoms_b_image( $src, $alt, $class = '' ) {
	$attrs = $class ? ',"className":"' . $class . '"' : '';
	$cls   = $class ? ' ' . $class : '';
	return "<!-- wp:image {\"sizeSlug\":\"large\",\"linkDestination\":\"media\"$attrs} -->\n<figure class=\"wp-block-image size-large$cls\"><a href=\"" . esc_url( $src ) . '"><img src="' . esc_url( $src ) . '" alt="' . esc_attr( $alt ) . "\"/></a></figure>\n<!-- /wp:image -->\n\n";
}

/** Static pages written for the new site, from the school's own text. */
function blossoms_new_pages() {
	$contact_rows = array(
		array( 'Address', '2 – 2A Nathibai Thackersey Road, New Marine Lines, Mumbai, Maharashtra' ),
		array( 'Phone', '<a href="tel:+912222015672">022 2201 5672</a> · <a href="tel:+912222088778">022 2208 8778</a>' ),
		array( 'Mobile', '<a href="tel:+919152133242">91521 33242</a>' ),
		array( 'School email', '<a href="mailto:blossomshighschool77@gmail.com">blossomshighschool77@gmail.com</a>' ),
		array( 'Admissions email', '<a href="mailto:blossomsadmission@gmail.com">blossomsadmission@gmail.com</a>' ),
	);
	$timings = blossoms_b_table(
		array(
			array( 'Pre-Primary section', '8:45 am – 12:00 noon' ),
			array( 'Primary &amp; Secondary sections', '8:45 am – 3:15 pm' ),
			array( 'School office (Monday – Friday)', '8:30 am – 4:30 pm' ),
			array( 'School office (Saturday)', '9:30 am – 2:00 pm' ),
		)
	);

	return array(
		'about-us'   => array( 'About Us',
			blossoms_b_h( 'Our history' ) .
			blossoms_b_p( 'The school was renamed The Blossoms Sunderbai Thackersey English School in 1981 and adopted the motto <em>तमसो मा ज्योतिर्गमय</em> — “Lead us from darkness to light”.' ) .
			blossoms_b_p( 'In 1993 the school was rechristened The Blossoms Sunderbai Thackersey English High School. From 30 “Little Angels”, the school has bloomed to the SSC level with a strength of 1,000 students.' ) .
			blossoms_b_h( 'Our mission' ) .
			blossoms_b_p( 'Our mission is to provide high-quality and meaningful education. At Blossoms we are committed to providing a learning environment that empowers children to become confident, compassionate and responsible learners. We aim to equip our students with the knowledge, skills and values that lead to their holistic development, making them individuals who contribute positively to society. Critical thinking, decision-making and a love of learning are nurtured.' ) .
			blossoms_b_h( 'Know more' ) .
			blossoms_b_list( array(
				'<a href=\"' . blossoms_url( 'our-founder' ) . '\">Our Founder</a>',
				'<a href=\"' . blossoms_url( 'from-principals-desk' ) . '\">From the Principal’s Desk</a>',
				'<a href=\"' . blossoms_url( 'vision-mission-values-motto' ) . '\">Vision, Mission, Values &amp; Motto</a>',
				'<a href=\"' . blossoms_url( 'school-song' ) . '\">School Song</a>',
				'<a href=\"' . blossoms_url( 'flag-and-house-system' ) . '\">Flag and House System</a>',
				'<a href=\"' . blossoms_url( 'our-uniform' ) . '\">Our Uniform</a>',
				'<a href=\"' . blossoms_url( 'school-timings' ) . '\">School Timings</a>',
				'<a href=\"' . blossoms_url( 'our-facilities' ) . '\">Facilities</a>',
			) ) .
			blossoms_b_h( 'School timings' ) . $timings
		),
		'admissions' => array( 'Admissions Open 2027–28',
			blossoms_b_p( '<strong>Admissions are open for Nursery, L.K.G., H.K.G. and Grade 1 for the Academic Year 2027–2028.</strong> Give your child the perfect foundation for a lifelong love of learning.' ) .
			blossoms_b_image( blossoms_admission_poster_url(), 'Admissions Open for the Academic Year 2027–2028 — The Blossoms Sunderbai Thackersey English High School', 'bh-admission-poster' ) .
			blossoms_b_h( 'Why choose The Blossoms?' ) .
			blossoms_b_list( array( 'Holistic, child-centric development', 'Experienced and caring faculty', 'Safe, joyful and nurturing campus', 'Dynamic co-curricular programmes' ) ) .
			blossoms_b_h( 'Eligibility criteria' ) .
			blossoms_b_table(
				array(
					array( 'Nursery', '1st October 2023 to 31st December 2024' ),
					array( 'L.K.G.', '1st October 2022 to 31st December 2023' ),
					array( 'H.K.G.', '1st October 2021 to 31st December 2022' ),
					array( 'Grade 1', '1st October 2020 to 31st December 2021' ),
				),
				array( 'Class', 'Children born between' )
			) .
			blossoms_b_h( 'Registration' ) .
			blossoms_b_list( array(
				'Forms will be available in the School Office from 16th October 2026 to 2nd November 2026, between 9.30 a.m. and 11.30 a.m. (except Sundays and Bank Holidays).',
				'Duly filled-in forms are to be submitted in the School Office before 2nd November 2026, between 9.30 a.m. and 11.30 a.m.',
				'Incomplete forms will not be accepted.',
			) ) .
			blossoms_b_p( '<strong>Required document:</strong> copy of the Birth Certificate.' ) .
			blossoms_b_h( 'For any enquiries, contact us' ) .
			blossoms_b_table( array( $contact_rows[4], $contact_rows[1], $contact_rows[2], $contact_rows[0] ) )
		),
		'contact'    => array( 'Contact', blossoms_b_table( $contact_rows ) . blossoms_b_h( 'School &amp; office timings' ) . $timings .
			"<!-- wp:html -->\n<iframe title=\"Map to The Blossoms school\" style=\"width:100%;height:360px;border:0;border-radius:12px\" src=\"https://maps.google.com/maps?q=The%20Blossoms%20High%20School%20Nathibai%20Thackersey%20Road%20Mumbai&amp;z=16&amp;output=embed\"></iframe>\n<!-- /wp:html -->\n\n" ),
		'career'     => array( 'Career', blossoms_b_h( 'New vacancies' ) . blossoms_b_p( 'To apply, please email your resume with a recent photograph and your academic and professional qualifications to <a href="mailto:blossomshighschool77@gmail.com">blossomshighschool77@gmail.com</a>.' ) ),
	);
}

/** Section pages that list their sub-pages, in the order the current site's menu uses. */
function blossoms_hubs() {
	return array(
		'academics-hub' => array( 'Academics', array( 'nursery', 'pre-primary' ) ),
		'achievements'  => array( 'Achievements', array( 'our-toppers', 'interschool-competition', 'competitive-examinations', 'achievement' ) ),
		'activities'    => array( 'Activities', array( 'one-day-picnic', 'teachers-picnic', 'summer-camp', 'abroad-trips', 'educational-trip', 'school-trips', 'scouts-camp', 'guide-camp', 'overnite-camp', 'competition', 'clubs', 'eco-club', 'literary-club', 'science-clubs', 'supw', 'class-activities' ) ),
		'events'        => array( 'Events', array( 'annual-day', 'annual-prize-distribution', 'annual-sports-day', 'investiture-ceremony', 'independence-day', 'children-day', 'christmas', 'diwali', 'teachers-day', 'satyanarayan-puja', 'hindi-diwas', 'may-day', 'ssc-farewell', 'ssc-students-felicitation' ) ),
		'sports'        => array( 'Sports', array( 'coaching', 'current-sports-winner' ) ),
	);
}

function blossoms_site_import() {
	if ( get_option( 'blossoms_site_imported' ) ) {
		return;
	}
	@set_time_limit( 0 );
	wp_defer_term_counting( true );
	wp_suspend_cache_invalidation( true );

	$data = json_decode( file_get_contents( __DIR__ . '/data/site-content.json' ), true );

	update_option( 'blogname', 'The Blossoms Sunderbai Thackersey English High School' );
	update_option( 'blogdescription', 'ICSE · CISCE Affiliation No. MA 297 · New Marine Lines, Mumbai' );
	update_option( 'permalink_structure', '/%postname%/' );
	update_option( 'timezone_string', 'Asia/Kolkata' );
	update_option( 'posts_per_page', 12 );

	foreach ( array( 1 => 'hello-world', 2 => 'sample-page' ) as $id => $slug ) {
		$p = get_post( $id );
		if ( $p && $p->post_name === $slug ) {
			wp_delete_post( $id, true );
		}
	}

	/* Categories */
	$cat_ids = array();
	foreach ( $data['categories'] as $c ) {
		$t                     = term_exists( $c['slug'], 'category' ) ?: wp_insert_term( $c['name'], 'category', array( 'slug' => $c['slug'] ) );
		$cat_ids[ $c['slug'] ] = is_wp_error( $t ) ? 0 : (int) $t['term_id'];
	}

	/* News posts */
	foreach ( $data['posts'] as $p ) {
		$id = wp_insert_post( array(
			'post_type'     => 'post',
			'post_status'   => 'publish',
			'post_name'     => $p['slug'],
			'post_title'    => wp_slash( $p['title'] ),
			'post_content'  => wp_slash( $p['content'] ),
			'post_excerpt'  => wp_slash( $p['excerpt'] ),
			'post_date'     => $p['date'],
			'post_category' => array_values( array_filter( array_map( fn( $s ) => $cat_ids[ $s ] ?? 0, $p['cats'] ) ) ),
		) );
		if ( $id && $p['image'] ) {
			update_post_meta( $id, '_blossoms_remote_thumb', esc_url_raw( $p['image'] ) );
		}
	}

	/* Pages from the current site */
	$ids = array();
	foreach ( $data['pages'] as $p ) {
		$ids[ $p['slug'] ] = wp_insert_post( array(
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_name'    => $p['slug'],
			'post_title'   => wp_slash( $p['title'] ),
			'post_content' => wp_slash( $p['content'] ),
		) );
	}

	/* Logo and admission poster, from the copies bundled with this plugin */
	update_option( 'blossoms_admission_poster_id', blossoms_import_asset( 'admission-poster.jpg', 'Admissions Open 2027–28 poster', 'image/jpeg' ) );
	$logo = blossoms_import_asset( 'blossoms-logo.png', 'The Blossoms logo', 'image/png' );
	if ( $logo ) {
		update_option( 'site_logo', $logo );
		$mods                = get_option( 'theme_mods_blossoms-heritage', array() );
		$mods['custom_logo'] = $logo;
		update_option( 'theme_mods_blossoms-heritage', $mods );
	}

	/* New pages */
	foreach ( blossoms_new_pages() as $slug => $p ) {
		$ids[ $slug ] = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => $slug, 'post_title' => $p[0], 'post_content' => wp_slash( $p[1] ) ) );
	}
	foreach ( blossoms_hubs() as $slug => $hub ) {
		$links = array();
		foreach ( $hub[1] as $child ) {
			if ( ! empty( $ids[ $child ] ) ) {
				$links[] = '<a href="' . blossoms_url( $child ) . '">' . esc_html( get_the_title( $ids[ $child ] ) ) . '</a>';
			}
		}
		$ids[ $slug ] = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => $slug, 'post_title' => $hub[0], 'post_content' => blossoms_b_list( $links ) ) );
	}
	$ids['home'] = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => 'home', 'post_title' => 'Home' ) );
	$ids['news'] = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => 'news', 'post_title' => 'News' ) );
	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $ids['home'] );
	update_option( 'page_for_posts', $ids['news'] );

	/* Main menu — same structure as the current site, plus Admissions Open */
	$link = fn( $label, $url ) => '<!-- wp:navigation-link {"label":"' . $label . '","url":"' . $url . '","kind":"custom"} /-->';
	$sub  = function ( $label, $url, $children ) use ( $link, $ids ) {
		$inner = '';
		foreach ( $children as $slug ) {
			if ( ! empty( $ids[ $slug ] ) ) {
				$inner .= $link( esc_html( get_the_title( $ids[ $slug ] ) ), blossoms_url( $slug ) );
			}
		}
		return '<!-- wp:navigation-submenu {"label":"' . $label . '","url":"' . $url . '","kind":"custom"} -->' . $inner . '<!-- /wp:navigation-submenu -->';
	};
	$hubs = blossoms_hubs();
	$nav  = $link( 'Home', blossoms_url() )
		. $sub( 'About Us', blossoms_url( 'about-us' ), array( 'our-founder', 'from-principals-desk', 'vision-mission-values-motto', 'school-song', 'flag-and-house-system', 'our-uniform', 'school-timings' ) )
		. $link( 'Facilities', blossoms_url( 'our-facilities' ) )
		. $sub( 'Academics', blossoms_url( 'academics-hub' ), $hubs['academics-hub'][1] )
		. $sub( 'Achievements', blossoms_url( 'achievements' ), $hubs['achievements'][1] )
		. $sub( 'Activities', blossoms_url( 'activities' ), $hubs['activities'][1] )
		. $sub( 'Events', blossoms_url( 'events' ), $hubs['events'][1] )
		. $sub( 'Sports', blossoms_url( 'sports' ), $hubs['sports'][1] )
		. $link( 'News', blossoms_url( 'news' ) )
		. '<!-- wp:navigation-link {"label":"Admissions Open","url":"' . blossoms_url( 'admissions' ) . '","kind":"custom","className":"bh-nav-admissions"} /-->'
		. $link( 'Contact', blossoms_url( 'contact' ) );
	wp_insert_post( array( 'post_type' => 'wp_navigation', 'post_status' => 'publish', 'post_title' => 'Main menu', 'post_content' => $nav ) );

	wp_suspend_cache_invalidation( false );
	wp_defer_term_counting( false );
	flush_rewrite_rules();
	update_option( 'blossoms_site_imported', 1 );
}
